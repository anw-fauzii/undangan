<div class="app-wrapper-footer">
    <div class="app-footer">
        <div class="app-footer__inner">
            <strong>&copy;2021 <a href="http://primainsani.sch.id" target="_blank">Yayasan Prima Insani</a>&nbsp;</strong>
                All rights reserved.
                <div class="float-right d-none d-sm-inline-block">
                &nbsp;<b>Version</b> 1.0.0
                </div>
        </div>
    </div>
</div> <?php /**PATH /home/primainsani/Documents/Laravel/undangan sd/resources/views/layouts/footer.blade.php ENDPATH**/ ?>